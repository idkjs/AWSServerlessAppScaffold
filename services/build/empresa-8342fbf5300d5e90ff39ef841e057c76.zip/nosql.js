"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
class NoSQL {
    constructor(endpoint) {
        this.endpoint = endpoint;
        this.documentClient = new aws_sdk_1.DynamoDB.DocumentClient();
    }
    getItem(tableName, itemId, callback) {
        console.log(`Get Item from ${tableName} using endpoint ${this.endpoint}`);
        const params = { TableName: tableName, Key: { "id": itemId } };
        this.documentClient.get(params).promise().then(value => {
            const item = value.Item;
            if (item) {
                const response = { statusCode: 200, body: JSON.stringify(value.Item) };
                callback(null, response);
            }
            else {
                const err = { statusCode: 404, message: 'Not Found' };
                const response = { statusCode: err.statusCode, body: JSON.stringify(err) };
                callback(null, response);
            }
        }).catch(reason => {
            const awserror = reason;
            const err = { statusCode: 500, message: awserror.message };
            callback(err, null);
        });
    }
}
exports.NoSQL = NoSQL;
