"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const nosqlCrud_1 = require("./nosqlCrud");
const itemKeyname = 'empresaId';
exports.handler = (event, context, cb) => {
    let crud = new nosqlCrud_1.CRUDHandler(itemKeyname);
    crud.handler(event, context, cb);
};
