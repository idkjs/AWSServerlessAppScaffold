"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const nosql_1 = require("./nosql");
function logResponse(context, response) {
    const logObject = {
        requestId: context.awsRequestId,
        response: response
    };
    console.log(logObject);
}
// @ts-ignore
exports.handler = (event, context, cb) => {
    const environment = process.env['DYNAMO_TABLE'];
    if (environment === undefined) {
        const response = { statusCode: 500, body: JSON.stringify({ message: 'Backend Function not Configured' }) };
        logResponse(context, response);
        cb(null, response);
    }
    else {
        const method = event.httpMethod;
        switch (method) {
            case 'GET': {
                const tableName = environment.toString();
                if (!event.pathParameters || !event.pathParameters.empresaId) {
                    const resultCode = 400;
                    const resultBody = { statusCode: resultCode, message: 'Bad Request: Invalid resourceId {empty}!' };
                    const response = { statusCode: resultCode, body: JSON.stringify(resultBody) };
                    logResponse(context, response);
                    cb(null, response);
                    return;
                }
                const itemId = event.pathParameters.empresaId;
                const nosql = new nosql_1.NoSQL();
                nosql.getItem(tableName, itemId, function (err, data) {
                    if (!err) {
                        logResponse(context, data);
                        cb(null, data);
                    }
                    else {
                        const errMsg = { statusCode: 500, body: JSON.stringify(err) };
                        logResponse(context, errMsg);
                        const response = { statusCode: 500, body: JSON.stringify({ statusCode: 500, message: 'Internal Server Error!' }) };
                        logResponse(context, response);
                        cb(null, response);
                    }
                });
                break;
            }
            default: {
                const responseBody = { statusCode: 405, message: 'Method Not Allowed' };
                const response = { statusCode: 405, body: JSON.stringify(responseBody) };
                logResponse(context, response);
                cb(null, response);
            }
        }
    }
};
