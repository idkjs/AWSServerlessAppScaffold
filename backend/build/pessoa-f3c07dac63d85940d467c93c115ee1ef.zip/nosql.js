"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const uuid_1 = require("uuid");
;
class NoSQL {
    constructor(endpoint) {
        this.endpoint = endpoint;
        this.documentClient = new aws_sdk_1.DynamoDB.DocumentClient();
    }
    getItem(tableName, itemId, callback) {
        console.log(`Get Item from ${tableName} using endpoint ${this.endpoint}`);
        const params = { TableName: tableName, Key: { "itemId": itemId } };
        this.documentClient.get(params).promise().then(value => {
            const item = value.Item;
            if (item) {
                const response = { statusCode: 200, body: JSON.stringify(value.Item), consumedCapacity: value.ConsumedCapacity };
                callback(null, response);
            }
            else {
                const err = { statusCode: 404, message: 'Not Found' };
                const response = { statusCode: err.statusCode, body: JSON.stringify(err), consumedCapacity: value.ConsumedCapacity };
                callback(null, response);
            }
        }).catch(reason => {
            const awserror = reason;
            const err = { statusCode: 500, message: awserror.message };
            callback(err, null);
        });
    }
    createItem(tableName, item, callback) {
        console.log(`Post Item into ${tableName} using endpoint ${this.endpoint}`);
        const itemId = uuid_1.v4();
        const body = Object.assign({ itemId: itemId }, item);
        const params = { TableName: tableName, Item: body };
        this.documentClient.put(params).promise().then(value => {
            const attributes = value.Attributes || body;
            const response = { statusCode: 201, body: JSON.stringify(attributes), consumedCapacity: value.ConsumedCapacity };
            callback(null, response);
        }).catch(reason => {
            const awserror = reason;
            const err = { statusCode: 500, message: awserror.message };
            callback(err, null);
        });
    }
    updateItem(tableName, itemId, item, callback) {
        console.log(`Update Item into ${tableName} using endpoint ${this.endpoint}`);
        const attributes = {};
        for (var attributename in item) {
            const updateexpression = { Action: 'PUT', Value: item[attributename] };
            attributes[attributename] = updateexpression;
        }
        const params = { TableName: tableName, Key: { "itemId": itemId }, AttributeUpdates: attributes };
        this.documentClient.update(params).promise().then(value => {
            const response = { statusCode: 201, body: '', consumedCapacity: value.ConsumedCapacity };
            callback(null, response);
        }).catch(reason => {
            const awserror = reason;
            const err = { statusCode: 500, message: awserror.message };
            callback(err, null);
        });
    }
    deleteItem(tableName, itemId, callback) {
        console.log(`Delete Item from ${tableName} using endpoint ${this.endpoint}`);
        const params = { TableName: tableName, Key: { "itemId": itemId } };
        this.documentClient.delete(params).promise().then(value => {
            const response = { statusCode: 200, body: '', consumedCapacity: value.ConsumedCapacity };
            callback(null, response);
        }).catch(reason => {
            const awserror = reason;
            const err = { statusCode: 500, message: awserror.message };
            callback(err, null);
        });
    }
}
exports.NoSQL = NoSQL;
