"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ContextUtils {
    logResponse(context, response) {
        const logObject = {
            requestId: context.awsRequestId,
            response: response
        };
        console.log(logObject);
    }
}
exports.ContextUtils = ContextUtils;
