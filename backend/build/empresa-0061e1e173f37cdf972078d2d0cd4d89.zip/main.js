"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const nosql_1 = require("./nosql");
const objectUtils_1 = require("./objectUtils");
// import * as url from 'Url';
const itemKeyname = 'empresaId';
function logResponse(context, response) {
    const logObject = {
        requestId: context.awsRequestId,
        response: response
    };
    console.log(logObject);
}
// @ts-ignore
exports.handler = (event, context, cb) => {
    const environment = process.env['DYNAMO_TABLE'];
    if (environment === undefined) {
        const response = { statusCode: 500, body: JSON.stringify({ message: 'Backend Function not Configured' }) };
        logResponse(context, response);
        cb(null, response);
    }
    else {
        const method = event.httpMethod;
        switch (method) {
            case 'POST': {
                const tableName = environment.toString();
                if (!event.body) {
                    const resultCode = 400;
                    const resultBody = { statusCode: resultCode, message: 'Bad Request: Invalid body {empty}!' };
                    const response = { statusCode: resultCode, body: JSON.stringify(resultBody) };
                    logResponse(context, response);
                    cb(null, response);
                    return;
                }
                const body = JSON.parse(event.body);
                const nosql = new nosql_1.NoSQL();
                nosql.createItem(tableName, body, function (err, data) {
                    if (!err) {
                        var returned = { statusCode: 200, body: '' };
                        if (data.statusCode === 201) {
                            let utils = new objectUtils_1.ObjectUtils();
                            var returnedBody = JSON.parse(data.body);
                            let itemId = returnedBody[itemKeyname];
                            returnedBody = utils.renameProperty(returnedBody, 'itemId', itemKeyname);
                            const baseUrl = process.env['BASE_URL'];
                            let url = baseUrl + event.path + itemId;
                            returned.statusCode = 201;
                            returned.body = JSON.stringify(returnedBody);
                            returned.headers = { Location: url };
                        }
                        else {
                            returned = Object.assign({}, data);
                        }
                        logResponse(context, returned);
                        cb(null, returned);
                    }
                    else {
                        const errMsg = { statusCode: 500, body: JSON.stringify(err) };
                        logResponse(context, errMsg);
                        const response = { statusCode: 500, body: JSON.stringify({ statusCode: 500, message: 'Internal Server Error!' }) };
                        logResponse(context, response);
                        cb(null, response);
                    }
                });
                break;
            }
            case 'GET': {
                const tableName = environment.toString();
                if (!event.pathParameters || !event.pathParameters[itemKeyname]) {
                    const resultCode = 400;
                    const resultBody = { statusCode: resultCode, message: 'Bad Request: Invalid resourceId {empty}!' };
                    const response = { statusCode: resultCode, body: JSON.stringify(resultBody) };
                    logResponse(context, response);
                    cb(null, response);
                    return;
                }
                const itemId = event.pathParameters[itemKeyname];
                const nosql = new nosql_1.NoSQL();
                nosql.getItem(tableName, itemId, function (err, data) {
                    if (!err) {
                        let utils = new objectUtils_1.ObjectUtils();
                        var returnedBody = JSON.parse(data.body);
                        returnedBody = utils.renameProperty(returnedBody, 'itemId', itemKeyname);
                        logResponse(context, data);
                        cb(null, returnedBody);
                    }
                    else {
                        const errMsg = { statusCode: 500, body: JSON.stringify(err) };
                        logResponse(context, errMsg);
                        const response = { statusCode: 500, body: JSON.stringify({ statusCode: 500, message: 'Internal Server Error!' }) };
                        logResponse(context, response);
                        cb(null, response);
                    }
                });
                break;
            }
            default: {
                const responseBody = { statusCode: 405, message: 'Method Not Allowed' };
                const response = { statusCode: 405, body: JSON.stringify(responseBody) };
                logResponse(context, response);
                cb(null, response);
            }
        }
    }
};
