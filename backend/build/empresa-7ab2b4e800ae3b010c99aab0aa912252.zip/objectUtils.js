"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class ObjectUtils {
    renameProperty(object, oldname, newname) {
        var value = object[oldname];
        var newObject = Object.assign({}, object);
        delete newObject[oldname];
        newObject[newname] = value;
        return newObject;
    }
}
exports.ObjectUtils = ObjectUtils;
